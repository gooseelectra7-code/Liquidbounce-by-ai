cd /d C:\Users\SYLVIA\Desktop\LBnew-main
"C:\Program Files\Git\bin\git.exe" push -u origin main
pause