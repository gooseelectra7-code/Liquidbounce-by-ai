/*
 * This file is part of LiquidBounce (https://github.com/CCBlueX/LiquidBounce)
 *
 * Copyright (c) 2015 - 2026 CCBlueX
 *
 * LiquidBounce is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * LiquidBounce is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with LiquidBounce. If not, see <https://www.gnu.org/licenses/>.
 */
package net.ccbluex.liquidbounce.interfaces;

/**
 * Addition to {@link net.minecraft.network.protocol.game.ClientboundRemoveEntitiesPacket}
 *
 * Upstream carried this for {@code CrystalAuraTriggerer}, which this fork's rewritten CrystalAura
 * does not have — nothing outside {@code MixinClientboundRemoveEntitiesPacket} reads the flag any
 * more. The doc link to that class is what broke the build: it imported a package this fork
 * deleted, and only a clean compile noticed, because a warm {@code build/} left :compileJava
 * UP-TO-DATE.
 */
public interface ClientboundRemoveEntitiesPacketAddition {

    /**
     * Flags the packet as containing a crystal.
     */
    @SuppressWarnings("unused")
    void liquid_bounce$setContainsCrystal();

    /**
     * Checks if the packet contains a crystal.
     */
    @SuppressWarnings("unused")
    boolean liquid_bounce$containsCrystal();

}
