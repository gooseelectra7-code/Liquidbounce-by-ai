$ErrorActionPreference = "Stop"

$JavaExe = "C:\Program Files\Java\jdk-25.0.4\bin\java.exe"
$ProjectDir = "C:\Users\SYLVIA\Desktop\LBnew-main"
$GradleWrapper = "$ProjectDir\gradle\wrapper\gradle-wrapper.jar"

Set-Location -Path $ProjectDir

# Verify files exist
if (-not (Test-Path $JavaExe)) {
    Write-Host "ERROR: Java not found at $JavaExe"
    exit 1
}
if (-not (Test-Path $GradleWrapper)) {
    Write-Host "ERROR: Gradle wrapper not found at $GradleWrapper"
    exit 1
}

Write-Host "Running Gradle build..."
Write-Host ""

# Run Gradle build - use --info for more details if build succeeds
& $JavaExe -Xms1024m -Xmx6144m -XX:+UseZGC -jar $GradleWrapper build -x detekt -x test --console=plain --info 2>&1

$ExitCode = $LASTEXITCODE
Write-Host ""
Write-Host "Exit code: $ExitCode"

# Check for JAR files
$JarFiles = Get-ChildItem -Path "$ProjectDir\build\libs" -Filter "*.jar" -File -ErrorAction SilentlyContinue
if ($JarFiles) {
    Write-Host "SUCCESS: JARs created:"
    $JarFiles | ForEach-Object { Write-Host "  $($_.Name)" }
} else {
    Write-Host "JAR not found in build\libs"
    Write-Host "Contents of build\libs:"
    Get-ChildItem -Path "$ProjectDir\build\libs" -ErrorAction SilentlyContinue | ForEach-Object { Write-Host "  $_" }
}

exit $ExitCode